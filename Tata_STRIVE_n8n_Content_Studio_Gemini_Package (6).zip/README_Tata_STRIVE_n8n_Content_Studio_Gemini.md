# Tata STRIVE n8n Content Studio — Free Gemini + Local Renderer

This is a ready-to-import n8n workflow that uses the Gemini API free tier for captions/hashtags and a small local Python/Pillow renderer for the PNG. It does **not** require an Ollama model download. Gemini requires an API key; selected models have a free tier subject to quota and availability. Do not enable billing just for this prototype.

## Files
- `Tata_STRIVE_n8n_Content_Studio_Gemini.json` — import this workflow into n8n.
- `render_server.py` — local PNG rendering helper.
- `assets/` — place the exact approved Tata STRIVE logo here as `tata-strive-logo.png`.

## 1. Get a free Gemini API key
1. Open https://aistudio.google.com/apikey
2. Create or copy an API key for the Gemini API.
3. You do not need to add a paid billing account to try eligible free-tier models. Free-tier quotas and model access can vary. See https://ai.google.dev/gemini-api/docs/pricing.
4. Do not share the key or publish it in a repository.

## 2. Add the key in the workflow
1. Import `Tata_STRIVE_n8n_Content_Studio_Gemini.json` into local n8n at http://localhost:5678.
2. Open the node **Generate Copy with Free Gemini API**.
3. Under **Header Parameters**, replace `PASTE_YOUR_FREE_GEMINI_API_KEY_HERE` with your key in the `x-goog-api-key` field.
4. Save the workflow. Keep this workflow local and do not export/share it after adding your real key. If you need to share the workflow, replace the key with the placeholder first.

The model configured is `gemini-3.8-flash`, which is listed by Google as available on the free tier, subject to its current limits. If your AI Studio key/account does not have access, select another model explicitly listed as free in AI Studio and update the model name in the HTTP Request URL.

## 3. Install the local image-render dependency
Open CMD in this extracted folder and run:

```cmd
py -m pip install --upgrade Pillow
```

If `py` is not recognised, try `python -m pip install --upgrade Pillow`.

## 4. Add the official logo
Save the exact approved logo supplied by Tata STRIVE as:

`assets\tata-strive-logo.png`

Do not use an AI-generated imitation of the logo. If the file is missing, the poster renderer shows a placeholder.

## 5. Start the renderer
Open a separate CMD window in this folder and run:

```cmd
py render_server.py
```

Keep it open. Verify the local endpoint by opening http://127.0.0.1:8765/health; it should return JSON with `"ok": true`.

## 6. Import and run the workflow
1. In n8n, use the workflow menu (`...`) and choose **Import from File**.
2. Select `Tata_STRIVE_n8n_Content_Studio_Gemini.json`.
3. Open the Gemini node and add the key as described above.
4. Start the renderer in a separate CMD window.
5. Execute the workflow and open the `Creative Brief Form` test form.
6. Enter the topic, opening line, verified facts, target audience, language and purpose.
7. Submit. The final step returns the PNG, caption, hashtags and alt-text files.

## What it generates
- A designed 1080x1350 PNG using local typography and shapes (not photorealistic diffusion-model artwork).
- `Tata_STRIVE_Caption.txt`
- `Tata_STRIVE_Hashtags.txt`
- `Tata_STRIVE_Alt_Text.txt`

It does not publish to Instagram. Review every output before use. The prompt instructs the model not to invent programme facts, event details, fees, eligibility or outcomes; supply verified facts in the form when required.

## Troubleshooting
- **Gemini 400/403/404:** Check the key, enabled API, account model availability, and model name. Use an eligible free-tier model from AI Studio.
- **429 / quota exceeded:** wait for the free quota to reset or reduce test requests; do not enable paid billing unless you deliberately choose to.
- **Renderer connection refused:** run `py render_server.py` and keep its CMD window open.
- **Logo placeholder appears:** verify the exact path and filename.
- **Text is not ideal:** review and edit the draft before publication.
