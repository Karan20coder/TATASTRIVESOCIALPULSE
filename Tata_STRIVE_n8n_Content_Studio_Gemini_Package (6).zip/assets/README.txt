Place the official Tata STRIVE logo supplied or approved by Tata STRIVE here as:
tata-strive-logo.png

The renderer uses the image as supplied and preserves its aspect ratio. If this file is absent, the generated graphic contains a visible placeholder instead of a fabricated logo.
