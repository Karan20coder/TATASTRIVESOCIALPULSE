#!/usr/bin/env python3
"""Local, no-API-key poster renderer for the Social Pulse n8n workflow.

Runs on 127.0.0.1:8765 and renders a 1080x1350 PNG using Pillow.
If assets/tata-strive-logo.png exists beside this script, it is placed as-is
(with aspect ratio preserved). Otherwise, a clearly marked logo placeholder is shown.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import base64
import io
import json
import textwrap
import re

HOST = "127.0.0.1"
PORT = 8765
BASE_DIR = Path(__file__).resolve().parent
LOGO_PATH = BASE_DIR / "assets" / "tata-strive-logo.png"
W, H = 1080, 1350

# A modern editorial palette; replace with approved brand guidelines if provided.
NAVY = (17, 32, 49)
NAVY2 = (28, 48, 67)
CREAM = (248, 246, 240)
WHITE = (255, 255, 255)
INK = (26, 37, 47)
MUTED = (86, 99, 109)
TEAL = (29, 126, 133)
GOLD = (219, 166, 98)
PALE = (230, 239, 235)


def font(size, bold=False):
    candidates = []
    if bold:
        candidates += [r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\segoeuib.ttf"]
    else:
        candidates += [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeui.ttf"]
    candidates += ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for p in candidates:
        try:
            return ImageFont.truetype(p, size=size)
        except (OSError, IOError):
            continue
    return ImageFont.load_default()


def clean_text(value, limit=1200):
    s = str(value or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s[:limit]


def wrap_by_width(draw, text, font_obj, max_width):
    words = clean_text(text, 1000).split()
    if not words:
        return []
    lines, current = [], ""
    for word in words:
        trial = word if not current else current + " " + word
        if draw.textbbox((0, 0), trial, font=font_obj)[2] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_wrapped(draw, text, xy, font_obj, fill, max_width, line_gap=12, max_lines=None):
    x, y = xy
    lines = wrap_by_width(draw, text, font_obj, max_width)
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[:max_lines]
        if lines:
            last = lines[-1]
            while last and draw.textbbox((0, 0), last + "…", font=font_obj)[2] > max_width:
                last = last[:-1]
            lines[-1] = last.rstrip() + "…"
    for line in lines:
        draw.text((x, y), line, font=font_obj, fill=fill)
        box = draw.textbbox((x, y), line, font=font_obj)
        y += (box[3] - box[1]) + line_gap
    return y, lines


def load_logo():
    if not LOGO_PATH.exists():
        return None
    try:
        logo = Image.open(LOGO_PATH).convert("RGBA")
        logo.thumbnail((300, 108), Image.Resampling.LANCZOS)
        return logo
    except Exception:
        return None


def render_poster(data):
    topic = clean_text(data.get("topic"), 160) or "Community Campaign"
    headline = clean_text(data.get("headline"), 160) or topic
    supporting = clean_text(data.get("supporting_text"), 350)
    cta = clean_text(data.get("cta"), 90) or "Learn more"
    audience = clean_text(data.get("audience"), 100)

    img = Image.new("RGB", (W, H), CREAM)
    draw = ImageDraw.Draw(img)

    # Top hero block and graphic shapes.
    draw.rounded_rectangle((-65, -70, 1145, 405), radius=80, fill=NAVY)
    draw.ellipse((785, -150, 1200, 260), fill=NAVY2)
    draw.ellipse((875, -70, 1125, 180), fill=TEAL)
    draw.ellipse((965, 10, 1080, 125), fill=GOLD)

    # Official logo: insert original asset unchanged, otherwise show an honest placeholder.
    logo = load_logo()
    if logo:
        # Light backing plate supports either light or transparent logos without altering pixels.
        draw.rounded_rectangle((68, 52, 390, 184), radius=22, fill=WHITE)
        img.alpha_composite(logo, (84, 64)) if img.mode == "RGBA" else img.paste(logo, (84, 64), logo)
    else:
        draw.rounded_rectangle((68, 52, 390, 184), radius=22, fill=(243, 239, 229), outline=(208, 198, 183), width=3)
        draw.text((92, 78), "OFFICIAL LOGO", font=font(25, True), fill=NAVY)
        draw.text((92, 116), "Add assets/tata-strive-logo.png", font=font(17), fill=MUTED)

    draw.text((70, 220), "TATA STRIVE  /  SOCIAL PULSE", font=font(22, True), fill=(240, 232, 218))
    draw.text((70, 264), "SKILLS  •  OPPORTUNITY  •  FUTURE", font=font(19, True), fill=(188, 211, 211))

    # Topic pill.
    pill = topic.upper()[:42]
    draw.rounded_rectangle((70, 450, 1010, 515), radius=28, fill=PALE)
    draw.text((96, 468), pill, font=font(21, True), fill=TEAL)

    # Headline: dynamically reduce font until it fits a reasonable number of lines.
    title_font = font(76, True)
    title_lines = wrap_by_width(draw, headline, title_font, 925)
    size = 76
    while len(title_lines) > 4 and size > 48:
        size -= 4
        title_font = font(size, True)
        title_lines = wrap_by_width(draw, headline, title_font, 925)
    title_y = 555
    title_y, _ = draw_wrapped(draw, headline, (72, title_y), title_font, INK, 925, line_gap=8, max_lines=4)

    # Accent rule.
    rule_y = min(max(title_y + 20, 825), 950)
    draw.rounded_rectangle((72, rule_y, 205, rule_y + 9), radius=5, fill=GOLD)

    body_y = rule_y + 36
    body_font = font(31)
    body_y, _ = draw_wrapped(draw, supporting or "A message about building skills, confidence and future opportunities.", (72, body_y), body_font, MUTED, 905, line_gap=10, max_lines=4)

    # CTA footer card.
    footer_y = 1110
    if body_y > 1055:
        footer_y = min(body_y + 22, 1140)
    draw.rounded_rectangle((70, footer_y, 1010, footer_y + 116), radius=28, fill=TEAL)
    draw.text((102, footer_y + 25), cta[:65], font=font(31, True), fill=WHITE)
    draw.text((102, footer_y + 70), "Discover more • Explore opportunities", font=font(19), fill=(226, 244, 241))

    # Footer line and draft indicator.
    draw.line((72, 1278, 1008, 1278), fill=(214, 207, 193), width=2)
    draw.text((72, 1294), "SOCIAL PULSE  •  DRAFT FOR REVIEW", font=font(16, True), fill=MUTED)
    if audience:
        # Audience appears in the metadata response; it is not forced onto the graphic.
        pass

    out = io.BytesIO()
    img.save(out, format="PNG", optimize=True)
    return out.getvalue()


class Handler(BaseHTTPRequestHandler):
    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "http://localhost:5678")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.rstrip("/") == "/health":
            self._json(200, {"ok": True, "service": "Social Pulse local poster renderer", "logo_found": LOGO_PATH.exists()})
        else:
            self._json(404, {"error": "Use POST /render or GET /health"})

    def do_POST(self):
        if self.path.rstrip("/") != "/render":
            self._json(404, {"error": "Use POST /render"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 2_000_000:
                self._json(413, {"error": "Request body is empty or too large"})
                return
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            png = render_poster(payload)
            hashtags = payload.get("hashtags", "")
            if isinstance(hashtags, list):
                hashtags = " ".join(str(x) for x in hashtags)
            resp = {
                "png_base64": base64.b64encode(png).decode("ascii"),
                "headline": clean_text(payload.get("headline"), 300),
                "topic": clean_text(payload.get("topic"), 200),
                "caption": clean_text(payload.get("caption"), 5000),
                "hashtags": clean_text(hashtags, 2000),
                "alt_text": clean_text(payload.get("alt_text"), 1000),
                "cta": clean_text(payload.get("cta"), 200),
                "width": W,
                "height": H,
                "logo_found": LOGO_PATH.exists(),
                "logo_note": "Official logo loaded" if LOGO_PATH.exists() else "Logo placeholder shown. Place the official logo at assets/tata-strive-logo.png and rerun."
            }
            self._json(200, resp)
        except Exception as exc:
            self._json(500, {"error": "Poster rendering failed", "detail": str(exc)[:500]})

    def log_message(self, fmt, *args):
        print("[renderer] " + (fmt % args))


if __name__ == "__main__":
    print(f"Social Pulse local poster renderer on http://{HOST}:{PORT}")
    print(f"Health check: http://{HOST}:{PORT}/health")
    print(f"Logo path: {LOGO_PATH}")
    print("Press Ctrl+C to stop.")
    HTTPServer((HOST, PORT), Handler).serve_forever()
